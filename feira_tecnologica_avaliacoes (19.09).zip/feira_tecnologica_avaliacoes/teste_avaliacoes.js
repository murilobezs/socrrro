// Script de teste para verificar se as correções funcionaram
// Execute no console do navegador para testar o sistema

console.log("=== TESTE DO SISTEMA DE AVALIAÇÕES ===");

// Função para testar a API de projetos do aluno
async function testarProjetosPorCriador() {
    console.log("\n1. Testando busca de projetos do aluno...");
    
    try {
        const usuarioStr = sessionStorage.getItem("usuario");
        if (!usuarioStr) {
            console.error("❌ Usuário não está logado");
            return;
        }
        
        const userData = JSON.parse(usuarioStr);
        const id_aluno = userData.usuario?.id_aluno || userData.id_aluno;
        
        console.log("ID do aluno:", id_aluno);
        
        const response = await fetch(`${BASE_URL}/api/projetos/meus`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id_aluno: id_aluno }),
            credentials: 'include'
        });
        
        if (response.ok) {
            const projetos = await response.json();
            console.log("✅ Projetos carregados:", projetos.length);
            console.log("Projetos:", projetos);
            
            projetos.forEach(projeto => {
                console.log(`- ${projeto.titulo_projeto}: ${projeto.status_avaliacao} (Nota: ${projeto.nota_final || 'N/A'})`);
            });
        } else {
            console.error("❌ Erro ao carregar projetos:", response.status);
        }
    } catch (error) {
        console.error("❌ Erro:", error);
    }
}

// Função para testar a API de notas do aluno
async function testarNotasDoAluno() {
    console.log("\n2. Testando busca de notas do aluno...");
    
    try {
        const usuarioStr = sessionStorage.getItem("usuario");
        if (!usuarioStr) {
            console.error("❌ Usuário não está logado");
            return;
        }
        
        const userData = JSON.parse(usuarioStr);
        const id_aluno = userData.usuario?.id_aluno || userData.id_aluno;
        
        const response = await fetch(`${BASE_URL}/api/notas/aluno?id_aluno=${id_aluno}`);
        
        if (response.ok) {
            const projetos = await response.json();
            console.log("✅ Projetos com notas carregados:", projetos.length);
            
            projetos.forEach(projeto => {
                console.log(`- ${projeto.titulo_projeto}:`);
                console.log(`  Status: ${projeto.status_avaliacao}`);
                console.log(`  Avaliações: ${projeto.qtd_avaliacoes}`);
                console.log(`  Nota final: ${projeto.media_final || 'N/A'}`);
                if (projeto.avaliacoes && projeto.avaliacoes.length > 0) {
                    projeto.avaliacoes.forEach(avaliacao => {
                        console.log(`  - ${avaliacao.nome_professor}: ${avaliacao.media}`);
                    });
                }
            });
        } else {
            console.error("❌ Erro ao carregar notas:", response.status);
        }
    } catch (error) {
        console.error("❌ Erro:", error);
    }
}

// Função para testar o dashboard
function testarDashboard() {
    console.log("\n3. Testando elementos do dashboard...");
    
    // Verificar se os elementos existem
    const elementos = [
        "meus-projetos-grid",
        "notas-container",
        "profile-nome",
        "stat-projetos",
        "stat-media"
    ];
    
    elementos.forEach(id => {
        const elemento = document.getElementById(id);
        if (elemento) {
            console.log(`✅ Elemento ${id} encontrado`);
        } else {
            console.log(`❌ Elemento ${id} NÃO encontrado`);
        }
    });
}

// Executar todos os testes
async function executarTestes() {
    console.log("Iniciando testes...");
    
    testarDashboard();
    await testarProjetosPorCriador();
    await testarNotasDoAluno();
    
    console.log("\n=== TESTES CONCLUÍDOS ===");
    console.log("Verifique os resultados acima para identificar problemas.");
}

// Executar os testes
executarTestes();