-- Arquivo de correção para problemas de avaliação no sistema
-- Execute este script no phpMyAdmin ou MySQL para corrigir os problemas

USE banco_feira;

-- Verificar se o campo criador_id existe na tabela projeto
-- Se não existir, adicionar (você já disse que adicionou)
-- ALTER TABLE projeto ADD COLUMN criador_id VARCHAR(20) AFTER nota_final;

-- Adicionar constraint foreign key para criador_id se ainda não existir
-- ALTER TABLE projeto ADD CONSTRAINT fk_projeto_criador 
-- FOREIGN KEY (criador_id) REFERENCES aluno(id_aluno);

-- Atualizar constraint de nota para usar ON DELETE CASCADE
ALTER TABLE nota DROP FOREIGN KEY nota_ibfk_2;
ALTER TABLE nota ADD CONSTRAINT nota_ibfk_2 
FOREIGN KEY (id_projeto) REFERENCES projeto(id_projeto) ON DELETE CASCADE;

-- Procedure para atualizar notas finais dos projetos baseado nas avaliações
DELIMITER //
CREATE PROCEDURE AtualizarNotasFinais()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE projeto_id INT;
    DECLARE nota_media DECIMAL(3,1);
    
    DECLARE projeto_cursor CURSOR FOR 
        SELECT p.id_projeto, ROUND(AVG(n.media), 1) as media_final
        FROM projeto p
        INNER JOIN nota n ON n.id_projeto = p.id_projeto
        GROUP BY p.id_projeto
        HAVING COUNT(n.id_nota) > 0;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN projeto_cursor;
    
    read_loop: LOOP
        FETCH projeto_cursor INTO projeto_id, nota_media;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        UPDATE projeto 
        SET nota_final = nota_media 
        WHERE id_projeto = projeto_id;
    END LOOP;
    
    CLOSE projeto_cursor;
END//
DELIMITER ;

-- Executar a procedure para atualizar as notas finais
CALL AtualizarNotasFinais();

-- Remover a procedure após o uso
DROP PROCEDURE AtualizarNotasFinais;

-- Verificar se há dados de teste
SELECT 'Verificando estrutura...' as status;
DESCRIBE projeto;

SELECT 'Projetos cadastrados:' as info, COUNT(*) as total FROM projeto;
SELECT 'Notas cadastradas:' as info, COUNT(*) as total FROM nota;
SELECT 'Projetos com notas:' as info, COUNT(DISTINCT p.id_projeto) as total 
FROM projeto p 
INNER JOIN nota n ON n.id_projeto = p.id_projeto;

-- Mostrar projetos e suas médias
SELECT 
    p.id_projeto,
    p.titulo_projeto,
    p.criador_id,
    COUNT(n.id_nota) as qtd_avaliacoes,
    ROUND(AVG(n.media), 1) as nota_final,
    p.nota_final as nota_final_salva
FROM projeto p
LEFT JOIN nota n ON n.id_projeto = p.id_projeto
GROUP BY p.id_projeto
ORDER BY p.id_projeto;