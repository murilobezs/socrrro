<?php
session_start();

header('Content-Type: application/json');

// Debug das sessões PHP
$debug_info = [
    'session_id' => session_id(),
    'session_data' => $_SESSION,
    'cookies' => $_COOKIE,
    'has_id_aluno' => isset($_SESSION['id_aluno']),
    'id_aluno_value' => $_SESSION['id_aluno'] ?? 'não definido'
];

echo json_encode($debug_info, JSON_PRETTY_PRINT);
?>