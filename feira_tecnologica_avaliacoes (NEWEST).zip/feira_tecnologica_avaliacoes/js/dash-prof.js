// Variáveis globais
let professorAtual = null;

document.addEventListener('DOMContentLoaded', function() {
    verificarAutenticacao();
    carregarDadosProfessor();
    carregarProjetos();
    
    // Deixar link ativo no nav
    const navLinks = document.querySelectorAll("nav a");
    window.addEventListener("scroll", () => {
      let fromTop = window.scrollY + 70;
      navLinks.forEach(link => {
        const section = document.querySelector(link.hash);
        if (section && section.offsetTop <= fromTop && section.offsetTop + section.offsetHeight > fromTop) {
          link.classList.add("active");
        } else {
          link.classList.remove("active");
        }
      });
    });
});

function verificarAutenticacao() {
    // Verificar se há dados do professor no localStorage
    const dadosUsuario = localStorage.getItem('usuario_logado');
    if (!dadosUsuario) {
        alert('Você precisa fazer login primeiro!');
        window.location.href = 'login professor.html';
        return;
    }
    
    try {
        professorAtual = JSON.parse(dadosUsuario);
        
        // Verificar se é realmente um professor
        if (professorAtual.tipo !== 'professor' && !professorAtual.matricula) {
            alert('Acesso negado! Esta área é apenas para professores.');
            window.location.href = 'escolha-login.html';
            return;
        }
    } catch (e) {
        console.error('Erro ao recuperar dados do professor:', e);
        window.location.href = 'login professor.html';
        return;
    }
}

function carregarDadosProfessor() {
    if (!professorAtual) return;
    
    // Atualizar o nome do professor na página
    const bemVindoElement = document.querySelector('.banner-text h1');
    if (bemVindoElement) {
        bemVindoElement.textContent = `Bem-vindo, Prof. ${professorAtual.nome || professorAtual.nome_professor || 'Professor'}`;
    }
    
    console.log('Professor logado:', professorAtual);
}

async function carregarProjetos() {
    if (!professorAtual) return;
    
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/projetos');
        
        if (!response.ok) {
            throw new Error('Erro ao carregar projetos');
        }
        
        const data = await response.json();
        let projetos = [];
        
        // Normalizar formato da resposta
        if (Array.isArray(data)) {
            projetos = data;
        } else if (data && Array.isArray(data.data)) {
            projetos = data.data;
        } else if (data && Array.isArray(data.projetos)) {
            projetos = data.projetos;
        }
        
        // Filtrar projetos atribuídos ao professor (se houver campo id_professor)
        const projetosProfessor = projetos.filter(projeto => 
            String(projeto.id_professor) === String(professorAtual.id || professorAtual.id_professor)
        );
        
        console.log('Projetos do professor:', projetosProfessor);
        
        // Atualizar contador de projetos pendentes
        atualizarContadorProjetos(projetosProfessor);
        
    } catch (error) {
        console.error('Erro ao carregar projetos:', error);
        
        // Se não conseguir carregar, mostrar dados padrão
        atualizarContadorProjetos([]);
    }
}

function atualizarContadorProjetos(projetos) {
    const numeroProjetosElement = document.querySelector('.numero-projetos');
    const textoProjetosElement = document.querySelector('.texto-projetos');
    const subtextoElement = document.querySelector('.subtexto');
    
    if (numeroProjetosElement) {
        numeroProjetosElement.textContent = projetos.length;
    }
    
    if (textoProjetosElement) {
        textoProjetosElement.textContent = projetos.length === 1 ? 'PROJETO' : 'PROJETOS';
    }
    
    if (subtextoElement) {
        if (projetos.length === 0) {
            subtextoElement.textContent = 'Nenhum projeto atribuído';
        } else {
            // Aqui você pode implementar lógica para verificar quais estão sem avaliação
            subtextoElement.textContent = 'Pendentes de avaliação';
        }
    }
    
    // Atualizar texto de pendências
    const textoPendenciaElement = document.querySelector('.texto-pendencia');
    if (textoPendenciaElement) {
        if (projetos.length === 0) {
            textoPendenciaElement.textContent = 'Nenhuma pendência no momento!';
        } else {
            textoPendenciaElement.textContent = 'Você possui pendências!';
        }
    }
}

function sairSistema() {
    if (confirm('Tem certeza que deseja sair do sistema?')) {
        // Limpar dados de autenticação
        localStorage.removeItem('usuario_logado');
        sessionStorage.removeItem('usuario');
        
        // Redirecionar para página de escolha de login
        window.location.href = 'escolha-login.html';
    }
}

// Evento botão sair
document.querySelector(".corremarreco").addEventListener("click", sairSistema);
