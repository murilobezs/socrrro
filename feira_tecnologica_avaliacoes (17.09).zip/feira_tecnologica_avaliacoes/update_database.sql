-- Script para adicionar campo criador_id na tabela projeto
-- Execute este script no banco de dados para adicionar o controle de autoria

USE banco_feira;

-- Adicionar coluna criador_id na tabela projeto
ALTER TABLE projeto ADD COLUMN criador_id VARCHAR(20) DEFAULT NULL;

-- Adicionar chave estrangeira relacionando com a tabela aluno
ALTER TABLE projeto ADD CONSTRAINT fk_projeto_criador 
FOREIGN KEY (criador_id) REFERENCES aluno(id_aluno) 
ON DELETE SET NULL ON UPDATE CASCADE;

-- Comentário: Este campo armazenará o ID do aluno que criou o projeto
-- Permitindo controle de autoria para edição