// Variáveis globais
let projetoAtual = null;
let selectedIntegrantes = new Set();
let selectedODS = new Set();
let alunosDisponiveis = [];
let odsDisponiveis = [];
let turmasDisponiveis = [];
let professoresDisponiveis = [];
let turmaSelecionada = null;
let orientadorSelecionado = null;

// Funções para modais
function showSuccessModal(message, callback) {
  const modal = document.getElementById('successModal');
  const messageEl = document.getElementById('successMessage');
  const btnOk = document.getElementById('btnOkSuccess');
  
  messageEl.textContent = message;
  modal.classList.add('show');
  
  btnOk.onclick = function() {
    modal.classList.remove('show');
    if (callback) callback();
  };
}

function showErrorModal(message) {
  const modal = document.getElementById('errorModal');
  const messageEl = document.getElementById('errorMessage');
  const btnOk = document.getElementById('btnOkError');
  
  messageEl.textContent = message;
  modal.classList.add('show');
  
  btnOk.onclick = function() {
    modal.classList.remove('show');
  };
}

function showConfirmModal(message, onConfirm) {
  const modal = document.getElementById('confirmModal');
  const messageEl = document.getElementById('confirmMessage');
  const btnSim = document.getElementById('btnSim');
  const btnNao = document.getElementById('btnNao');
  
  messageEl.textContent = message;
  modal.classList.add('show');
  
  btnSim.onclick = function() {
    modal.classList.remove('show');
    if (onConfirm) onConfirm();
  };
  
  btnNao.onclick = function() {
    modal.classList.remove('show');
  };
}

document.addEventListener('DOMContentLoaded', function() {
    // Configurar interface
    configurarInterfacePorTipoUsuario();
    
    // Carregar dados iniciais
    carregarTurmas();
    carregarODS();
    carregarProfessores();
    
    // Carregar projeto para edição
    carregarProjeto();

    // Event listeners
    const turmaSelect = document.getElementById("turmaSelect");
    if (turmaSelect) {
        turmaSelect.addEventListener('change', function(e) {
            turmaSelecionada = e.target.value;
            if (turmaSelecionada) {
                carregarAlunosPorTurma(turmaSelecionada);
            } else {
                alunosDisponiveis = [];
                atualizarSelectIntegrantes();
            }
        });
    }

    const orientadorSelect = document.getElementById("orientadorSelect");
    if (orientadorSelect) {
        orientadorSelect.addEventListener('change', function(e) {
            orientadorSelecionado = e.target.value;
        });
    }

    const integrantesSelect = document.getElementById("integrantesSelect");
    if (integrantesSelect) {
        integrantesSelect.addEventListener('change', function(e) {
            if (e.target.value) {
                adicionarIntegrante();
            }
        });
    }

    const form = document.querySelector('#formEditarProjeto');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            salvarProjeto();
        });
    }
});

function configurarInterfacePorTipoUsuario() {
    configurarInterfaceODS();
}

function configurarInterfaceODS() {
    const odsContainer = document.getElementById("odsContainer");
    if (odsContainer) {
        odsContainer.innerHTML = `
            <div class="ods-select-wrapper">
                <select class="integrantes-select" id="odsSelect">
                    <option value="">Carregando ODS...</option>
                </select>
            </div>
            <div class="integrantes-selected-list" id="odsSelectedList"></div>
        `;

        const odsSelect = document.getElementById("odsSelect");
        if (odsSelect) {
            odsSelect.addEventListener('change', function(e) {
                if (e.target.value) {
                    adicionarODS();
                }
            });
        }
    }
}

function carregarProjeto() {
    const urlParams = new URLSearchParams(window.location.search);
    const idProjeto = urlParams.get('id') || localStorage.getItem('projeto_visualizacao');
    if (idProjeto) {
        buscarDadosProjeto(idProjeto);
    } else {
        mostrarErro('Nenhum projeto selecionado para edição');
    }
}

async function buscarDadosProjeto(idProjeto) {
    try {
        // Buscar dados do projeto
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/projetos');
        
        if (!response.ok) {
            throw new Error('Erro ao buscar projetos');
        }

        const data = await response.json();
        let projetos = Array.isArray(data) ? data : (data.data || []);
        
        projetoAtual = projetos.find(p => String(p.id_projeto) === String(idProjeto));
        
        if (!projetoAtual) {
            throw new Error('Projeto não encontrado');
        }

        // Buscar integrantes do projeto
        await carregarIntegrantesProjeto(idProjeto);
        
        // Buscar ODS do projeto
        await carregarODSProjeto(idProjeto);
        
        // Preencher formulário
        preencherFormulario();
        
    } catch (error) {
        console.error('Erro ao carregar projeto:', error);
        mostrarErro('Erro ao carregar dados do projeto');
    }
}

async function carregarIntegrantesProjeto(idProjeto) {
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/projetos/alunos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id_projeto: idProjeto })
        });

        if (response.ok) {
            const alunos = await response.json();
            alunos.forEach(aluno => {
                if (aluno.id_aluno) {
                    selectedIntegrantes.add(aluno.id_aluno);
                }
            });
        }
    } catch (error) {
        console.error('Erro ao carregar integrantes:', error);
    }
}

async function carregarODSProjeto(idProjeto) {
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/projetos/ods-projeto', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id_projeto: idProjeto })
        });

        if (response.ok) {
            const odsList = await response.json();
            odsList.forEach(ods => {
                if (ods.id_ods) {
                    selectedODS.add(String(ods.id_ods));
                }
            });
        }
    } catch (error) {
        console.error('Erro ao carregar ODS:', error);
    }
}

function preencherFormulario() {
    if (!projetoAtual) return;

    // Preencher campos básicos
    document.getElementById('titulo_projeto').value = projetoAtual.titulo_projeto || '';
    document.getElementById('projetoId').value = projetoAtual.id_projeto;

    // Extrair descrição, objetivo e justificativa
    const fullDesc = projetoAtual.descricao || '';
    let descText = fullDesc;
    let objText = '';
    let justText = '';
    
    const objMatch = /Objetivo[:]?\s*/i.exec(fullDesc);
    const justMatch = /Justificativa[:]?\s*/i.exec(fullDesc);
    
    if (objMatch) {
        const objIndex = objMatch.index;
        descText = fullDesc.substring(0, objIndex).trim();
        if (justMatch) {
            objText = fullDesc.substring(objIndex + objMatch[0].length, justMatch.index).trim();
            justText = fullDesc.substring(justMatch.index + justMatch[0].length).trim();
        } else {
            objText = fullDesc.substring(objIndex + objMatch[0].length).trim();
        }
    }

    document.getElementById('descricao').value = descText;
    document.getElementById('objetivo').value = objText;
    document.getElementById('justificativa').value = justText;

    // Definir turma selecionada
    turmaSelecionada = projetoAtual.turma;
    
    // Definir orientador selecionado
    orientadorSelecionado = projetoAtual.orientador;
    
    // Atualizar informações do stand
    document.getElementById('standInfo').textContent = `STAND ${projetoAtual.posicao || '--'}`;
    document.getElementById('turmaInfo').innerHTML = `${projetoAtual.turma || 'Turma não definida'}<br>--`;

    // Atualizar listas
    updateIntegrantesList();
    updateODSList();
    
    // Atualizar informações dos integrantes
    atualizarInfoIntegrantes();
}

// Funções auxiliares similares ao criar_projeto.js
async function carregarProfessores() {
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/professores');
        
        if (response.ok) {
            const data = await response.json();
            professoresDisponiveis = Array.isArray(data) ? data : (data.data || []);
            console.log('Professores carregados:', professoresDisponiveis);
            atualizarSelectProfessores();
        } else {
            console.error('Erro na resposta da API professores:', response.status, response.statusText);
            professoresDisponiveis = [];
            atualizarSelectProfessores();
        }
    } catch (error) {
        console.error('Erro ao carregar professores:', error);
        professoresDisponiveis = [];
        atualizarSelectProfessores();
    }
}

function atualizarSelectProfessores() {
    const select = document.getElementById("orientadorSelect");
    if (!select) return;
    
    if (professoresDisponiveis.length > 0) {
        select.innerHTML = '<option value="">Selecione um professor orientador...</option>';
        professoresDisponiveis.forEach(professor => {
            const option = document.createElement('option');
            // Usar nome_professor da API /api/professores
            const nome = professor.nome_professor || professor.nome;
            option.value = nome;
            option.textContent = nome;
            if (option.value === orientadorSelecionado) {
                option.selected = true;
            }
            select.appendChild(option);
        });
        select.disabled = false;
    } else {
        select.innerHTML = '<option value="">Nenhum professor encontrado</option>';
        select.disabled = true;
    }
}

async function carregarTurmas() {
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/turmas');
        
        if (response.ok) {
            const data = await response.json();
            turmasDisponiveis = Array.isArray(data) ? data : (data.data || []);
            atualizarSelectTurmas();
        }
    } catch (error) {
        console.error('Erro ao carregar turmas:', error);
    }
}

function atualizarSelectTurmas() {
    const select = document.getElementById("turmaSelect");
    if (!select) return;
    
    if (turmasDisponiveis.length > 0) {
        select.innerHTML = '<option value="">Selecione uma turma...</option>';
        turmasDisponiveis.forEach(turma => {
            const option = document.createElement('option');
            option.value = turma.nome_turma || turma.nome || turma.codigo || turma.id_turma;
            option.textContent = turma.nome_turma || turma.nome || turma.codigo || turma.id_turma;
            if (option.value === turmaSelecionada) {
                option.selected = true;
            }
            select.appendChild(option);
        });
        select.disabled = false;
        
        // Se já há uma turma selecionada, carregar os alunos e remover required
        if (turmaSelecionada) {
            carregarAlunosPorTurma(turmaSelecionada);
            select.removeAttribute('required');
        }
    } else {
        select.innerHTML = '<option value="">Nenhuma turma encontrada</option>';
        select.disabled = true;
    }
}

async function carregarODS() {
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/ods');
        
        if (response.ok) {
            const data = await response.json();
            odsDisponiveis = Array.isArray(data) ? data : (data.data || []);
            atualizarSelectODS();
        }
    } catch (error) {
        console.error('Erro ao carregar ODS:', error);
    }
}

function atualizarSelectODS() {
    const select = document.getElementById("odsSelect");
    if (!select) return;

    if (odsDisponiveis.length > 0) {
        select.innerHTML = '<option value="">Selecione uma ODS...</option>';
        odsDisponiveis.forEach(ods => {
            const option = document.createElement('option');
            option.value = ods.id_ods;
            option.textContent = `ODS ${ods.id_ods} - ${ods.nome}`;
            select.appendChild(option);
        });
        select.disabled = false;
    } else {
        select.innerHTML = '<option value="">Nenhuma ODS encontrada</option>';
        select.disabled = true;
    }
}

async function carregarAlunosPorTurma(turma) {
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(`${apiBase}/api/usuarios?turma=${encodeURIComponent(turma)}`);
        
        if (response.ok) {
            const data = await response.json();
            alunosDisponiveis = Array.isArray(data) ? data : (data.data || []);
            atualizarSelectIntegrantes();
            
            // Atualizar lista e informações dos integrantes após carregar os alunos
            updateIntegrantesList();
            atualizarInfoIntegrantes();
        }
    } catch (error) {
        console.error('Erro ao carregar alunos:', error);
        alunosDisponiveis = [];
        atualizarSelectIntegrantes();
    }
}

function atualizarSelectIntegrantes() {
    const select = document.getElementById("integrantesSelect");
    if (!select) return;

    if (alunosDisponiveis.length > 0) {
        select.innerHTML = '<option value="">Selecione um integrante...</option>';
        alunosDisponiveis.forEach(aluno => {
            const option = document.createElement('option');
            option.value = aluno.id_aluno;
            option.textContent = aluno.nome_aluno || aluno.nome;
            select.appendChild(option);
        });
        select.disabled = false;
    } else {
        select.innerHTML = '<option value="">Selecione uma turma primeiro...</option>';
        select.disabled = true;
    }
}

function adicionarIntegrante() {
    const select = document.getElementById("integrantesSelect");
    if (!select.value) return;

    selectedIntegrantes.add(select.value);
    select.value = "";
    updateIntegrantesList();
    atualizarInfoIntegrantes();
}

function removerIntegrante(id_aluno) {
    selectedIntegrantes.delete(id_aluno);
    updateIntegrantesList();
    atualizarInfoIntegrantes();
}

function adicionarODS() {
    const select = document.getElementById("odsSelect");
    if (!select.value) return;

    selectedODS.add(select.value);
    select.value = "";
    updateODSList();
}

function removerODS(id_ods) {
    selectedODS.delete(id_ods);
    updateODSList();
}

function updateIntegrantesList() {
    const listContainer = document.getElementById("integrantesSelectedList");
    
    if (selectedIntegrantes.size === 0) {
        listContainer.innerHTML = '<div class="integrantes-empty">Nenhum integrante selecionado</div>';
        return;
    }
    
    listContainer.innerHTML = Array.from(selectedIntegrantes).map(id_aluno => {
        const aluno = alunosDisponiveis.find(a => a.id_aluno === id_aluno);
        const nome = aluno ? (aluno.nome_aluno || aluno.nome) : `ID: ${id_aluno}`;
        return `
            <div class="integrante-item">
                <span>${nome}</span>
                <button type="button" class="remove-integrante-btn" onclick="removerIntegrante('${id_aluno}')">×</button>
            </div>
        `;
    }).join('');
}

function atualizarInfoIntegrantes() {
    const infoElement = document.getElementById("integrantesInfo");
    if (!infoElement) return;
    
    if (selectedIntegrantes.size > 0) {
        const nomes = Array.from(selectedIntegrantes).map(id_aluno => {
            const aluno = alunosDisponiveis.find(a => a.id_aluno === id_aluno);
            return aluno ? (aluno.nome_aluno || aluno.nome) : `ID: ${id_aluno}`;
        });
        
        infoElement.textContent = `Integrantes atuais: ${nomes.join(', ')}`;
        infoElement.className = 'info-text has-integrantes';
    } else {
        infoElement.textContent = 'Nenhum integrante cadastrado no projeto.';
        infoElement.className = 'info-text';
    }
}

function updateODSList() {
    const listContainer = document.getElementById("odsSelectedList");
    
    if (selectedODS.size === 0) {
        listContainer.innerHTML = '<div class="ods-empty">Nenhuma ODS selecionada</div>';
        return;
    }
    
    listContainer.innerHTML = Array.from(selectedODS).map(id_ods => {
        const ods = odsDisponiveis.find(o => o.id_ods == id_ods);
        const nome = ods ? `ODS ${ods.id_ods} - ${ods.nome}` : `ODS ${id_ods}`;
        return `
            <div class="ods-item">
                <span>${nome}</span>
                <button type="button" class="remove-ods-btn" onclick="removerODS('${id_ods}')">×</button>
            </div>
        `;
    }).join('');
}

async function salvarProjeto() {
    if (!projetoAtual || !projetoAtual.id_projeto) {
        showErrorModal('Projeto inválido.');
        return;
    }

    const nomeProjeto = document.getElementById("titulo_projeto").value;
    const descricao = document.getElementById("descricao").value;
    const objetivo = document.getElementById("objetivo").value;
    const justificativa = document.getElementById("justificativa").value;
    const orientadorAtual = document.getElementById("orientadorSelect").value;

    // Validação: só exigir turma se não há uma já definida
    const turmaParaUsar = turmaSelecionada || projetoAtual.turma;
    
    if (!nomeProjeto || !descricao || !turmaParaUsar) {
        showErrorModal("Preencha todos os campos obrigatórios.");
        return;
    }

    // Preparar descrição completa
    const descricaoCompleta = descricao + 
        (objetivo ? `\n\nObjetivo: ${objetivo}` : '') + 
        (justificativa ? `\n\nJustificativa: ${justificativa}` : '');

    // Tentar obter informações do usuário logado
    let criador_id = null;
    try {
        const usuarioStr = sessionStorage.getItem("usuario");
        if (usuarioStr) {
            const data = JSON.parse(usuarioStr);
            const usuario = data.usuario || data;
            criador_id = usuario.id_aluno || usuario.RM || usuario.rm || data.id_aluno || data.RM || data.rm;
        }
    } catch (e) {
        console.log('Não foi possível obter dados do usuário logado:', e);
    }

    const dadosAtualizados = {
        id_projeto: projetoAtual.id_projeto,
        titulo_projeto: nomeProjeto,
        descricao: descricaoCompleta,
        turma: turmaParaUsar,
        orientador: orientadorAtual || orientadorSelecionado || projetoAtual.orientador,
        integrantes: Array.from(selectedIntegrantes),
        ods: Array.from(selectedODS).map(id => parseInt(id))
    };

    // Incluir criador_id se disponível
    if (criador_id) {
        dadosAtualizados.criador_id = criador_id;
    }

    console.log('Dados sendo enviados para atualização:', dadosAtualizados);

    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        const response = await fetch(apiBase + '/api/projetos/editar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dadosAtualizados),
            credentials: 'include' // Inclui cookies de sessão
        });

        const resultado = await response.json();

        if (response.ok) {
            showSuccessModal('Projeto atualizado com sucesso!', function() {
                window.location.href = `visualizar_projeto.html?id=${projetoAtual.id_projeto}`;
            });
        } else {
            showErrorModal('Erro ao atualizar projeto: ' + (resultado.erro || resultado.message || 'Erro desconhecido'));
        }
    } catch (error) {
        console.error('Erro ao salvar projeto:', error);
        showErrorModal('Erro de conexão ao salvar o projeto.');
    }
}

function mostrarErro(mensagem) {
    const container = document.querySelector('.content-container');
    if (container) {
        container.innerHTML = `<div class="error-message" style="color:#ff4444;text-align:center;padding:20px;">
            ${mensagem}
        </div>`;
    }
}
