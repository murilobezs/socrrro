// Variáveis globais
let professorAtual = null;

document.addEventListener('DOMContentLoaded', function() {
    verificarAutenticacao();
    carregarDadosProfessor();
    carregarProjetos();
    
    // Deixar link ativo no nav
    const navLinks = document.querySelectorAll("nav a");
    window.addEventListener("scroll", () => {
      let fromTop = window.scrollY + 70;
      navLinks.forEach(link => {
        const section = document.querySelector(link.hash);
        if (section && section.offsetTop <= fromTop && section.offsetTop + section.offsetHeight > fromTop) {
          link.classList.add("active");
        } else {
          link.classList.remove("active");
        }
      });
    });
});

function verificarAutenticacao() {
    // Verificar se há dados do professor no localStorage
    const dadosUsuario = localStorage.getItem('usuario_logado');
    if (!dadosUsuario) {
        alert('Você precisa fazer login primeiro!');
        window.location.href = 'login professor.html';
        return;
    }
    
    try {
        professorAtual = JSON.parse(dadosUsuario);
        
        // Normalizar dados - pode estar em professorAtual.usuario ou direto em professorAtual
        const usuario = professorAtual.usuario || professorAtual;
        
        // Verificar se é realmente um professor de forma mais robusta
        const isProfessor = usuario.tipo === 'professor' || 
                           usuario.matricula || 
                           usuario.id_professor || 
                           usuario.nome_professor;
        
        console.log('Dados do usuário:', usuario);
        console.log('É professor?', isProfessor);
        
        if (!isProfessor) {
            alert('Acesso negado! Esta área é apenas para professores.');
            window.location.href = 'escolha-login.html';
            return;
        }
        
        // Garantir que professorAtual tenha a estrutura correta
        if (professorAtual.usuario) {
            professorAtual = professorAtual.usuario;
        }
    } catch (e) {
        console.error('Erro ao recuperar dados do professor:', e);
        window.location.href = 'login professor.html';
        return;
    }
}

function carregarDadosProfessor() {
    if (!professorAtual) return;
    
    // Atualizar o nome do professor na página
    const bemVindoElement = document.querySelector('.banner-text h1');
    if (bemVindoElement) {
        bemVindoElement.textContent = `Bem-vindo, Prof. ${professorAtual.nome || professorAtual.nome_professor || 'Professor'}`;
    }
    
    console.log('Professor logado:', professorAtual);
}

async function carregarProjetos() {
    if (!professorAtual) return;
    
    try {
        const apiBase = (window.BASE_URL || '').replace(/\/$/, '');
        
        // Carregar projetos e notas em paralelo
        const [projetosResponse, notasResponse] = await Promise.all([
            fetch(apiBase + '/api/projetos'),
            fetch(apiBase + `/api/notas/projetos?id_professor=${professorAtual.id || professorAtual.id_professor}`)
        ]);
        
        if (!projetosResponse.ok) {
            throw new Error('Erro ao carregar projetos');
        }
        
        const projetosData = await projetosResponse.json();
        let todosProjetos = [];
        
        // Normalizar formato da resposta
        if (Array.isArray(projetosData)) {
            todosProjetos = projetosData;
        } else if (projetosData && Array.isArray(projetosData.data)) {
            todosProjetos = projetosData.data;
        } else if (projetosData && Array.isArray(projetosData.projetos)) {
            todosProjetos = projetosData.projetos;
        }
        
        // Buscar informações das notas se a requisição foi bem-sucedida
        let notasProjetos = [];
        if (notasResponse.ok) {
            notasProjetos = await notasResponse.json();
        }
        
        // Para o dashboard, mostraremos todos os projetos disponíveis para avaliação
        // e calcularemos quantos estão pendentes para este professor específico
        const projetosComStatus = todosProjetos.map(projeto => {
            const nota = notasProjetos.find(n => n.id_projeto === projeto.id_projeto);
            return {
                ...projeto,
                avaliado: nota ? true : false,
                media: nota ? nota.media : null
            };
        });
        
        // Contar projetos pendentes (não avaliados pelo professor atual)
        const projetosPendentes = projetosComStatus.filter(projeto => !projeto.avaliado);
        
        console.log('Todos os projetos:', projetosComStatus);
        console.log('Projetos pendentes de avaliação:', projetosPendentes);
        
        // Atualizar contador de projetos pendentes
        atualizarContadorProjetos(projetosPendentes, projetosComStatus.length);
        
    } catch (error) {
        console.error('Erro ao carregar projetos:', error);
        
        // Se não conseguir carregar, mostrar dados padrão
        atualizarContadorProjetos([], 0);
    }
}

function atualizarContadorProjetos(projetosPendentes, totalProjetos = 0) {
    const numeroProjetosElement = document.querySelector('.numero-projetos');
    const textoProjetosElement = document.querySelector('.texto-projetos');
    const subtextoElement = document.querySelector('.subtexto');
    
    if (numeroProjetosElement) {
        numeroProjetosElement.textContent = projetosPendentes.length;
    }
    
    if (textoProjetosElement) {
        textoProjetosElement.textContent = projetosPendentes.length === 1 ? 'PROJETO' : 'PROJETOS';
    }
    
    if (subtextoElement) {
        if (projetosPendentes.length === 0) {
            if (totalProjetos === 0) {
                subtextoElement.textContent = 'Nenhum projeto disponível';
            } else {
                subtextoElement.textContent = 'Todos projetos avaliados';
            }
        } else {
            subtextoElement.textContent = 'Pendentes de avaliação';
        }
    }
    
    // Atualizar texto de pendências
    const textoPendenciaElement = document.querySelector('.texto-pendencia');
    if (textoPendenciaElement) {
        if (projetosPendentes.length === 0) {
            if (totalProjetos === 0) {
                textoPendenciaElement.textContent = 'Nenhum projeto disponível!';
            } else {
                textoPendenciaElement.textContent = 'Parabéns! Todas as avaliações foram concluídas!';
            }
        } else {
            textoPendenciaElement.textContent = 'Você possui pendências!';
        }
    }
    
    // Mostrar informações adicionais se houver projetos avaliados
    if (totalProjetos > projetosPendentes.length) {
        const projetosAvaliados = totalProjetos - projetosPendentes.length;
        console.log(`Projetos avaliados: ${projetosAvaliados}/${totalProjetos}`);
        
        // Adicionar indicador visual de progresso (opcional)
        const progressoElement = document.querySelector('.progresso-avaliacoes');
        if (progressoElement) {
            const percentual = Math.round((projetosAvaliados / totalProjetos) * 100);
            progressoElement.textContent = `Progresso: ${percentual}% (${projetosAvaliados}/${totalProjetos})`;
        }
    }
}

function sairSistema() {
    if (confirm('Tem certeza que deseja sair do sistema?')) {
        // Limpar dados de autenticação
        localStorage.removeItem('usuario_logado');
        sessionStorage.removeItem('usuario');
        
        // Redirecionar para página de escolha de login
        window.location.href = 'escolha-login.html';
    }
}

// Evento botão sair
document.querySelector(".corremarreco").addEventListener("click", sairSistema);
