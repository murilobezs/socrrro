// JavaScript para o Dashboard do Aluno
let meusProjetos = [];
let minhasNotas = [];

document.addEventListener("DOMContentLoaded", function () {
    exibirSaudacaoUsuario();
    carregarMeusProjetos();
    carregarPerfilUsuario();
    configurarPesquisa();
});

// Função para exibir a saudação personalizada
function exibirSaudacaoUsuario() {
    const saudacaoElem = document.getElementById("saudacao");
    const usuarioStr = sessionStorage.getItem("usuario");
    
    if (usuarioStr && saudacaoElem) {
        const data = JSON.parse(usuarioStr);
        const usuario = data.usuario || data;
        const nome = usuario.nome || usuario.nome_aluno || usuario.nome_professor || "Aluno";
        saudacaoElem.textContent = `Olá, ${nome}!`;
    }
}

// Sistema de abas
function showTab(tabName) {
    // Esconder todas as abas
    const tabPanes = document.querySelectorAll('.tab-pane');
    tabPanes.forEach(pane => {
        pane.classList.remove('active');
    });
    
    // Remover active de todos os botões
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Mostrar aba selecionada
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }
    
    // Ativar botão correspondente
    const activeBtn = document.getElementById(`tab-${tabName.split('-')[1]}`);
    if (activeBtn) {
        activeBtn.classList.add('active');
    }
    
    // Carregar conteúdo específico da aba
    switch(tabName) {
        case 'meus-projetos':
            if (meusProjetos.length === 0) {
                carregarMeusProjetos();
            }
            break;
        case 'minhas-notas':
            if (minhasNotas.length === 0) {
                carregarMinhasNotas();
            }
            break;
        case 'meu-perfil':
            carregarPerfilUsuario();
            break;
    }
}

// Carregamento dos projetos do usuário
async function carregarMeusProjetos() {
    try {
        const grid = document.getElementById("meus-projetos-grid");
        grid.innerHTML = '<div class="loading">Carregando seus projetos...</div>';
        
        // Obter ID do usuário do sessionStorage
        const usuarioStr = sessionStorage.getItem("usuario");
        if (!usuarioStr) {
            mostrarErro(grid, "Usuário não autenticado. Faça login novamente.");
            return;
        }
        
        let data, usuario, id_aluno;
        
        try {
            data = JSON.parse(usuarioStr);
            usuario = data.usuario || data;
            
            // Tentar várias formas de obter o ID do aluno
            id_aluno = usuario.id_aluno || 
                      usuario.RM || 
                      usuario.rm || 
                      data.id_aluno ||
                      data.RM ||
                      data.rm;
                      
            console.log("SessionStorage bruto:", usuarioStr);
            console.log("Dados parseados:", data);
            console.log("Usuario extraído:", usuario);
            console.log("ID aluno encontrado:", id_aluno);
            
        } catch (e) {
            console.error("Erro ao processar sessionStorage:", e);
            mostrarErro(grid, "Erro ao processar dados do usuário.");
            return;
        }
        
        if (!id_aluno) {
            console.error("ID do aluno não encontrado. Dados disponíveis:", {data, usuario});
            mostrarErro(grid, "ID do usuário não encontrado. Verifique o console para mais detalhes.");
            return;
        }
        
        const url = window.BASE_URL + "/api/projetos/meus";
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id_aluno: id_aluno }),
            credentials: 'include'
        });
        
        if (response.ok) {
            const data = await response.json();
            meusProjetos = Array.isArray(data) ? data : [];
            renderizarMeusProjetos();
        } else {
            const errorData = await response.json();
            mostrarErro(grid, errorData.message || "Erro ao carregar projetos");
        }
    } catch (error) {
        console.error("Erro ao carregar projetos:", error);
        const grid = document.getElementById("meus-projetos-grid");
        mostrarErro(grid, "Erro de conexão. Verifique sua conexão com a internet.");
    }
}

// Renderizar projetos do usuário
async function renderizarMeusProjetos() {
    const grid = document.getElementById("meus-projetos-grid");
    grid.innerHTML = "";
    
    if (meusProjetos.length === 0) {
        grid.innerHTML = `
            <div class="empty-state">
                <i class="material-icons">assignment</i>
                <h3>Nenhum projeto encontrado</h3>
                <p>Você ainda não criou nenhum projeto. Clique em "CRIAR PROJETO" para começar!</p>
            </div>
        `;
        return;
    }
    
    // Carregar dados dos professores para exibir nomes
    await carregarNomesProfessores();
    
    meusProjetos.forEach(projeto => {
        const card = criarCardMeuProjeto(projeto);
        grid.appendChild(card);
    });
}

// Carrega os nomes dos professores para exibir nos cards
async function carregarNomesProfessores() {
    try {
        console.log('=== CARREGANDO PROFESSORES ===');
        console.log('Projetos antes do mapeamento:', meusProjetos);
        
        const response = await fetch(window.BASE_URL + '/api/professores', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include'
        });
        
        if (response.ok) {
            const professores = await response.json();
            console.log('Professores carregados:', professores);
            
            if (Array.isArray(professores)) {
                // Adicionar nome do professor aos projetos
                meusProjetos.forEach(projeto => {
                    console.log('Projeto:', projeto.titulo_projeto, ', orientador:', projeto.orientador);
                    if (projeto.orientador) {
                        const professor = professores.find(p => 
                            String(p.id_professor) === String(projeto.orientador)
                        );
                        if (professor) {
                            projeto.nome_orientador = professor.nome_professor;
                            console.log('Mapeado orientador:', professor.nome_professor, 'para projeto:', projeto.titulo_projeto);
                        } else {
                            console.log('Professor não encontrado para ID:', projeto.orientador);
                        }
                    } else {
                        console.log('Projeto sem orientador:', projeto.titulo_projeto);
                    }
                });
                
                console.log('Projetos após mapeamento:', meusProjetos);
            }
        }
    } catch (error) {
        console.error('Erro ao carregar professores:', error);
    }
}

// Criar card para projeto do usuário
function criarCardMeuProjeto(projeto) {
    const card = document.createElement("div");
    card.className = "project-card meu-projeto";
    
    // Status do projeto baseado na nota final
    const status = projeto.nota_final ? 'Avaliado' : 'Aguardando Avaliação';
    const statusClass = projeto.nota_final ? 'status-avaliado' : 'status-pendente';
    
    card.innerHTML = `
        <div class="project-header">
            <h3>${projeto.titulo_projeto}</h3>
            <span class="projeto-status ${statusClass}">${status}</span>
        </div>
        <p class="project-description">${projeto.descricao || 'Sem descrição'}</p>
        <div class="project-info">
            <p><strong>Orientador:</strong> ${projeto.nome_orientador || "Não definido"}</p>
            <p><strong>Turma:</strong> ${projeto.turma || "N/A"}</p>
            <p><strong>Stand:</strong> ${projeto.posicao || "N/A"}</p>
            ${projeto.nota_final ? `<p><strong>Nota Final:</strong> <span class="nota-valor">${projeto.nota_final}</span></p>` : ''}
        </div>
        <div class="card-actions">
            <button class="btn-enter" onclick="visualizarProjeto('${projeto.id_projeto}')">
                <i class="material-icons">visibility</i> Visualizar
            </button>
            <button class="btn-edit" onclick="editarProjeto('${projeto.id_projeto}')">
                <i class="material-icons">edit</i> Editar
            </button>
        </div>
    `;
    
    return card;
}

// Carregamento das notas do usuário
async function carregarMinhasNotas() {
    try {
        const container = document.getElementById("notas-container");
        container.innerHTML = '<div class="loading">Carregando suas avaliações...</div>';
        
        // Obter ID do usuário do sessionStorage
        const usuarioStr = sessionStorage.getItem("usuario");
        if (!usuarioStr) {
            mostrarErro(container, "Usuário não autenticado. Faça login novamente.");
            return;
        }
        
        let data, usuario, id_aluno;
        
        try {
            data = JSON.parse(usuarioStr);
            usuario = data.usuario || data;
            
            // Tentar várias formas de obter o ID do aluno
            id_aluno = usuario.id_aluno || 
                      usuario.RM || 
                      usuario.rm || 
                      data.id_aluno ||
                      data.RM ||
                      data.rm;
                      
        } catch (parseError) {
            console.error("Erro ao processar dados do usuário:", parseError);
            mostrarErro(container, "Erro nos dados do usuário");
            return;
        }
        
        if (!id_aluno) {
            mostrarErro(container, "ID do aluno não encontrado");
            return;
        }
        
        // Buscar notas do backend
        const response = await fetch(`${BASE_URL}/api/notas/aluno?id_aluno=${id_aluno}`);
        
        if (!response.ok) {
            throw new Error(`Erro ${response.status}: ${response.statusText}`);
        }
        
        const projetos = await response.json();
        console.log("Projetos com notas:", projetos);
        
        if (projetos.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="material-icons" style="font-size: 3rem; color: #ccc;">assignment</i>
                    <h4>Nenhum projeto encontrado</h4>
                    <p>Você ainda não possui projetos cadastrados.</p>
                    <button class="btn-create" onclick="window.location.href='criar_projeto.html'">
                        <i class="material-icons">add</i>
                        CRIAR PRIMEIRO PROJETO
                    </button>
                </div>
            `;
            return;
        }
        
        // Verificar se há projetos avaliados
        const projetosAvaliados = projetos.filter(p => p.status_avaliacao === 'Avaliado');
        const projetosPendentes = projetos.filter(p => p.status_avaliacao === 'Aguardando Avaliação');
        
        let html = '<div class="notas-summary">';
        
        // Resumo das avaliações
        html += `
            <div class="stats-row">
                <div class="stat-item">
                    <span class="stat-number">${projetos.length}</span>
                    <span class="stat-label">Total de Projetos</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">${projetosAvaliados.length}</span>
                    <span class="stat-label">Avaliados</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">${projetosPendentes.length}</span>
                    <span class="stat-label">Aguardando</span>
                </div>
            </div>
        `;
        
        if (projetosAvaliados.length > 0) {
            html += `
                <div class="notas-redirect">
                    <h4>Você possui ${projetosAvaliados.length} projeto(s) avaliado(s)!</h4>
                    <p>Clique no botão abaixo para ver todas as suas avaliações detalhadas.</p>
                    <button class="btn-create" onclick="window.location.href='notas_alunos.html'">
                        <i class="material-icons">grade</i>
                        VER MINHAS NOTAS
                    </button>
                </div>
            `;
        } else {
            html += `
                <div class="notas-pending">
                    <h4>Aguardando Avaliações</h4>
                    <p>Seus projetos ainda estão sendo avaliados pelos professores.</p>
                    <i class="material-icons" style="font-size: 3rem; color: #ffa726;">pending</i>
                </div>
            `;
        }
        
        html += '</div>';
        
        // Lista de projetos com status
        html += '<div class="projetos-status">';
        html += '<h4>Status dos Seus Projetos</h4>';
        
        projetos.forEach(projeto => {
            const statusClass = projeto.status_avaliacao === 'Avaliado' ? 'avaliado' : 'pendente';
            const statusIcon = projeto.status_avaliacao === 'Avaliado' ? 'check_circle' : 'pending';
            const media = projeto.media_final ? `(Nota: ${projeto.media_final})` : '';
            
            html += `
                <div class="projeto-status ${statusClass}">
                    <div class="projeto-info">
                        <h5>${projeto.titulo_projeto}</h5>
                        <p class="projeto-status-text">
                            <i class="material-icons">${statusIcon}</i>
                            ${projeto.status_avaliacao} ${media}
                        </p>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        
        container.innerHTML = html;
        
        // Armazenar para uso em outras funções
        minhasNotas = projetos;
        
    } catch (error) {
        console.error("Erro ao carregar notas:", error);
        const container = document.getElementById("notas-container");
        mostrarErro(container, "Erro ao carregar avaliações. Tente novamente.");
    }
}

// Carregamento do perfil do usuário
function carregarPerfilUsuario() {
    const usuarioStr = sessionStorage.getItem("usuario");
    
    if (usuarioStr) {
        const data = JSON.parse(usuarioStr);
        const usuario = data.usuario || data;
        
        // Preencher dados do perfil
        document.getElementById("profile-nome").textContent = 
            usuario.nome || usuario.nome_aluno || "Nome não disponível";
        document.getElementById("profile-rm").textContent = 
            `RM: ${usuario.rm || usuario.RM || "----"}`;
        document.getElementById("profile-email").textContent = 
            usuario.email || usuario.email_institucional || "email@etec.sp.gov.br";
        document.getElementById("profile-total-projetos").textContent = 
            `Total de projetos: ${meusProjetos.length}`;
        
        // Atualizar estatísticas
        document.getElementById("stat-projetos").textContent = meusProjetos.length;
        
        // Calcular nota média baseada nas notas reais
        if (minhasNotas && minhasNotas.length > 0) {
            const projetosComNota = minhasNotas.filter(p => p.media_final && p.media_final > 0);
            const media = projetosComNota.length > 0 
                ? (projetosComNota.reduce((sum, p) => sum + parseFloat(p.media_final || 0), 0) / projetosComNota.length).toFixed(1)
                : "0.0";
            document.getElementById("stat-media").textContent = media;
        } else {
            document.getElementById("stat-media").textContent = "0.0";
        }
    }
}

// Configurar pesquisa nos projetos
function configurarPesquisa() {
    const inputPesquisa = document.getElementById("searchMeusProjetos");
    if (inputPesquisa) {
        inputPesquisa.addEventListener("input", function(e) {
            const termo = e.target.value.toLowerCase();
            filtrarMeusProjetos(termo);
        });
    }
}

// Filtrar projetos do usuário
function filtrarMeusProjetos(termo) {
    const projetosFiltrados = termo ? 
        meusProjetos.filter(projeto => 
            projeto.titulo_projeto.toLowerCase().includes(termo) ||
            (projeto.descricao && projeto.descricao.toLowerCase().includes(termo)) ||
            (projeto.nome_orientador && projeto.nome_orientador.toLowerCase().includes(termo))
        ) : meusProjetos;
    
    renderizarProjetosFiltrados(projetosFiltrados);
}

// Renderizar projetos filtrados
function renderizarProjetosFiltrados(projetos) {
    const grid = document.getElementById("meus-projetos-grid");
    grid.innerHTML = "";
    
    if (projetos.length === 0) {
        grid.innerHTML = `
            <div class="empty-state">
                <i class="material-icons">search_off</i>
                <h3>Nenhum projeto encontrado</h3>
                <p>Nenhum projeto corresponde aos termos da sua pesquisa.</p>
            </div>
        `;
        return;
    }
    
    projetos.forEach(projeto => {
        const card = criarCardMeuProjeto(projeto);
        grid.appendChild(card);
    });
}

// Navegação para outras páginas
function visualizarProjeto(idProjeto) {
    localStorage.setItem("projeto_visualizacao", idProjeto);
    window.location.href = "visualizar_projeto.html";
}

function editarProjeto(idProjeto) {
    localStorage.setItem("projeto_edicao", idProjeto);
    window.location.href = "editar_projeto.html";
}

// Função de logout
function logout() {
    if (confirm("Tem certeza que deseja sair?")) {
        // Limpar dados da sessão
        sessionStorage.clear();
        localStorage.clear();
        
        // Redirecionar para a página de login
        window.location.href = "escolha-login.html";
    }
}

// Mostrar erro
function mostrarErro(container, mensagem) {
    container.innerHTML = `
        <div class="error-state">
            <i class="material-icons">error_outline</i>
            <h3>Erro</h3>
            <p>${mensagem}</p>
        </div>
    `;
}

// CSS adicional inline para novos estilos
const style = document.createElement('style');
style.textContent = `
    .meu-projeto {
        border-left: 4px solid #672D91;
    }
    
    .project-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 1rem;
    }
    
    .projeto-status {
        font-size: 0.8rem;
        padding: 0.3rem 0.8rem;
        border-radius: 12px;
        font-weight: 500;
    }
    
    .status-avaliado {
        background: rgba(76, 175, 80, 0.2);
        color: #4CAF50;
        border: 1px solid rgba(76, 175, 80, 0.3);
    }
    
    .status-pendente {
        background: rgba(255, 193, 7, 0.2);
        color: #FFC107;
        border: 1px solid rgba(255, 193, 7, 0.3);
    }
    
    .project-description {
        color: rgba(255, 255, 255, 0.8);
        margin-bottom: 1rem;
        font-size: 0.9rem;
    }
    
    .project-info {
        margin-bottom: 1.5rem;
    }
    
    .project-info p {
        color: rgba(255, 255, 255, 0.7);
        margin-bottom: 0.3rem;
        font-size: 0.9rem;
    }
    
    .btn-edit {
        background: linear-gradient(135deg, #672D91, #8A5ABF);
        color: #FFFFFF;
        border: none;
        padding: 0.6rem 1rem;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-family: 'Poppins', sans-serif;
        font-size: 0.9rem;
    }
    
    .btn-edit:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(103, 45, 145, 0.3);
    }
    
    .notas-redirect {
        text-align: center;
        padding: 2rem;
    }
    
    .notas-redirect h4 {
        color: #FFFFFF;
        margin-bottom: 1rem;
    }
    
    .notas-redirect p {
        color: #D2B4FF;
        margin-bottom: 2rem;
    }
`;
document.head.appendChild(style);