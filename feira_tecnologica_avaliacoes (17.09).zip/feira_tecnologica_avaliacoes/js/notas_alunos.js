// JavaScript para a página de notas dos alunos
document.addEventListener("DOMContentLoaded", function () {
    carregarNotasDoAluno();
});

// Função para obter ID do aluno do sessionStorage
function obterIdAluno() {
    const usuarioStr = sessionStorage.getItem("usuario");
    if (!usuarioStr) {
        console.error("Usuário não autenticado");
        return null;
    }
    
    try {
        const data = JSON.parse(usuarioStr);
        const usuario = data.usuario || data;
        
        return usuario.id_aluno || 
               usuario.RM || 
               usuario.rm || 
               data.id_aluno ||
               data.RM ||
               data.rm;
    } catch (error) {
        console.error("Erro ao processar dados do usuário:", error);
        return null;
    }
}

// Função para calcular a menção baseada na média
function calcularMencao(media) {
    if (media >= 9.0) return "MB"; // Muito Bom
    if (media >= 7.0) return "B";  // Bom
    if (media >= 5.0) return "R";  // Regular
    return "I"; // Insuficiente
}

// Função para carregar as notas do aluno
async function carregarNotasDoAluno() {
    const id_aluno = obterIdAluno();
    
    if (!id_aluno) {
        mostrarErro("Erro: Usuário não autenticado ou ID do aluno não encontrado.");
        return;
    }

    try {
        const response = await fetch(`${BASE_URL}/api/notas/aluno?id_aluno=${id_aluno}`);
        
        if (!response.ok) {
            throw new Error(`Erro ${response.status}: ${response.statusText}`);
        }
        
        const projetos = await response.json();
        console.log("Projetos com notas:", projetos);
        
        if (projetos.length === 0) {
            mostrarMensagem("Você ainda não possui projetos cadastrados.");
            return;
        }
        
        // Procurar por projetos que possuem avaliações
        const projetosAvaliados = projetos.filter(p => p.avaliacoes && p.avaliacoes.length > 0);
        
        if (projetosAvaliados.length === 0) {
            mostrarMensagem("Seus projetos ainda estão aguardando avaliação.");
            return;
        }
        
        // Exibir o primeiro projeto avaliado
        exibirNotasNaTabela(projetosAvaliados[0]);
        
    } catch (error) {
        console.error("Erro ao carregar notas:", error);
        mostrarErro("Erro ao carregar suas notas. Tente novamente mais tarde.");
    }
}

// Função para exibir as notas na tabela
function exibirNotasNaTabela(projeto) {
    const avaliacoes = projeto.avaliacoes;
    
    if (!avaliacoes || avaliacoes.length === 0) {
        mostrarMensagem("Este projeto ainda não foi avaliado.");
        return;
    }
    
    // Criar cabeçalho da tabela
    const table = document.querySelector('.avaliacao table');
    if (!table) {
        console.error("Tabela não encontrada");
        return;
    }
    
    // Limpar tabela existente
    table.innerHTML = '';
    
    // Criar cabeçalho
    const headerRow = document.createElement('tr');
    headerRow.innerHTML = '<th>Critérios</th>';
    
    // Adicionar colunas para cada avaliador
    avaliacoes.forEach((avaliacao, index) => {
        headerRow.innerHTML += `<th>A${index + 1}</th>`;
    });
    
    table.appendChild(headerRow);
    
    // Critérios de avaliação
    const criterios = [
        { nome: 'Oralidade', campo: 'oralidade' },
        { nome: 'Postura', campo: 'postura' },
        { nome: 'Organização', campo: 'organizacao' },
        { nome: 'Criatividade', campo: 'criatividade' },
        { nome: 'Capricho', campo: 'capricho' },
        { nome: 'Domínio', campo: 'dominio' },
        { nome: 'Abordagem', campo: 'abordagem' }
    ];
    
    // Adicionar linhas para cada critério
    criterios.forEach(criterio => {
        const row = document.createElement('tr');
        row.innerHTML = `<td>${criterio.nome}</td>`;
        
        avaliacoes.forEach(avaliacao => {
            row.innerHTML += `<td>${parseFloat(avaliacao[criterio.campo]).toFixed(1)}</td>`;
        });
        
        table.appendChild(row);
    });
    
    // Linha com média por avaliador
    const mediaRow = document.createElement('tr');
    mediaRow.className = 'linha-destaque';
    mediaRow.innerHTML = '<td>Média por avaliador</td>';
    
    avaliacoes.forEach(avaliacao => {
        mediaRow.innerHTML += `<td>${parseFloat(avaliacao.media).toFixed(2)}</td>`;
    });
    
    table.appendChild(mediaRow);
    
    // Calcular e exibir média final
    const mediaFinal = projeto.media_final || 0;
    const mediaFinalRow = document.createElement('tr');
    mediaFinalRow.className = 'linha-destaque';
    mediaFinalRow.innerHTML = `<td>Média final</td><td colspan="${avaliacoes.length}">${mediaFinal.toFixed(2)}</td>`;
    table.appendChild(mediaFinalRow);
    
    // Linha com menção
    const mencao = calcularMencao(mediaFinal);
    const mencaoRow = document.createElement('tr');
    mencaoRow.className = 'linha-destaque';
    mencaoRow.innerHTML = `<td>Menção</td><td colspan="${avaliacoes.length}" class="mencao">${mencao}</td>`;
    table.appendChild(mencaoRow);
    
    // Atualizar feedbacks
    atualizarFeedbacks(avaliacoes);
}

// Função para atualizar os feedbacks
function atualizarFeedbacks(avaliacoes) {
    const feedbacksContainer = document.querySelector('.feedbacks');
    if (!feedbacksContainer) return;
    
    // Limpar feedbacks existentes
    const feedbacksExistentes = feedbacksContainer.querySelectorAll('.feedback');
    feedbacksExistentes.forEach(feedback => feedback.remove());
    
    // Adicionar novos feedbacks
    avaliacoes.forEach((avaliacao, index) => {
        if (avaliacao.comentario && avaliacao.comentario.trim() !== '') {
            const feedbackDiv = document.createElement('div');
            feedbackDiv.className = 'feedback';
            feedbackDiv.innerHTML = `
                <div>
                    <strong>${avaliacao.nome_professor || `Professor ${index + 1}`}</strong>
                    <p>${avaliacao.comentario}</p>
                </div>
                <img src="img/Vector.png" alt="">
            `;
            feedbacksContainer.appendChild(feedbackDiv);
        }
    });
}

// Função para mostrar erro
function mostrarErro(mensagem) {
    const container = document.querySelector('.content-container');
    if (container) {
        container.innerHTML = `
            <div class="error-message" style="text-align: center; padding: 2rem; color: #d32f2f;">
                <h3>Erro</h3>
                <p>${mensagem}</p>
                <button onclick="window.location.reload()" style="margin-top: 1rem; padding: 0.5rem 1rem; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer;">
                    Tentar Novamente
                </button>
            </div>
        `;
    }
}

// Função para mostrar mensagem
function mostrarMensagem(mensagem) {
    const container = document.querySelector('.avaliacao');
    if (container) {
        container.innerHTML = `
            <div class="info-message" style="text-align: center; padding: 2rem;">
                <h3>Informação</h3>
                <p>${mensagem}</p>
                <button onclick="window.location.href='dashboard_aluno.html'" style="margin-top: 1rem; padding: 0.5rem 1rem; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer;">
                    Voltar ao Dashboard
                </button>
            </div>
        `;
    }
}